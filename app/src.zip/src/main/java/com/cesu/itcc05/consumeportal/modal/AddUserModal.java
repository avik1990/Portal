package com.cesu.itcc05.consumeportal.modal;

public class AddUserModal {
    String consumerId="";
    String name="";
    String address="";

    public  AddUserModal(){

    }

    public String getConsumerId() {
        return consumerId;
    }

    public void setConsumerId(String consumerId) {
        this.consumerId = consumerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
