package com.cesu.itcc05.consumeportal;

public class ComplainModal {
    String id="";
    String comapinReaon="";
    String categoryId="";

    public ComplainModal(){

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getComapinReaon() {
        return comapinReaon;
    }

    public void setComapinReaon(String comapinReaon) {
        this.comapinReaon = comapinReaon;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }
}
