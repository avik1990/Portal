package com.cesu.itcc05.consumeportal;

public class BaseActivity {
}
