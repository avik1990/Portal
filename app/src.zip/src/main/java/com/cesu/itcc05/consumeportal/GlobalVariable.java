package com.cesu.itcc05.consumeportal;

import com.cesu.itcc05.consumeportal.modal.OfferSchemModal;

import java.util.ArrayList;
import java.util.List;

public class GlobalVariable {
    public static List<OfferSchemModal>offerSchemModals=new ArrayList<>();
}
