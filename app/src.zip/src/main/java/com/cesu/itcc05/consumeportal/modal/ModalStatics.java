package com.cesu.itcc05.consumeportal.modal;

public class ModalStatics {

    String tileName="";
    String clickDate="";
    String clickTime="";

    public ModalStatics(){

    }

    public String getTileName() {
        return tileName;
    }

    public void setTileName(String tileName) {
        this.tileName = tileName;
    }

    public String getClickDate() {
        return clickDate;
    }

    public void setClickDate(String clickDate) {
        this.clickDate = clickDate;
    }

    public String getClickTime() {
        return clickTime;
    }

    public void setClickTime(String clickTime) {
        this.clickTime = clickTime;
    }
}
