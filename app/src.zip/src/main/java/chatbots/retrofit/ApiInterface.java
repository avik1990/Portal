package chatbots.retrofit;


import java.util.List;

import chatbots.model.AnswerResponse;
import chatbots.model.QuestionResponse;
import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiInterface {
    @GET("chatbot_Questions?checksum=01091981")
    Call<List<QuestionResponse>> getAllQuestions();
   // http://www.json-generator.com/api/json/get/bTAqcRGofC?indent=2
  /*  @GET("get/ckyRcRZBua?indent=2")
    Call<AnswerResponse> getAllAnswers();

    @GET("get/cfOVCNPSeW?indent=2")
    Call<AnswerResponse> getImageAnswers();

    @GET("get/ceIazfoFDS?indent=2")
    Call<List<AnswerResponse>> getLocations();*/

    //http://www.json-generator.com/api/json/get/ceIazfoFDS?indent=2

}

